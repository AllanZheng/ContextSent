make clean
rm -rf CMakeFiles cmake_install.cmake CMakeCache.txt Makefile
rm -rf */CMakeFiles */cmake_install.cmake */Makefile
